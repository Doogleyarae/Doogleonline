import { pgTable, text, serial, integer, boolean, timestamp, decimal, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: varchar("role", { length: 20 }).notNull().default("admin"), // Only admins can log in
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const exchangeRates = pgTable("exchange_rates", {
  id: serial("id").primaryKey(),
  fromCurrency: varchar("from_currency", { length: 20 }).notNull(),
  toCurrency: varchar("to_currency", { length: 20 }).notNull(),
  rate: decimal("rate", { precision: 10, scale: 6 }).notNull(),
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: varchar("order_number", { length: 20 }).notNull().unique(),
  customerName: text("customer_name").notNull(),
  customerPhone: varchar("customer_phone", { length: 20 }).notNull(),
  customerEmail: varchar("customer_email", { length: 255 }).notNull(),
  customerAccount: text("customer_account").notNull(),
  fromCurrency: varchar("from_currency", { length: 20 }).notNull(),
  toCurrency: varchar("to_currency", { length: 20 }).notNull(),
  fromAmount: decimal("from_amount", { precision: 15, scale: 2 }).notNull(),
  toAmount: decimal("to_amount", { precision: 15, scale: 2 }).notNull(),
  exchangeRate: decimal("exchange_rate", { precision: 10, scale: 6 }).notNull(),
  paymentMethod: varchar("payment_method", { length: 50 }).notNull(),
  status: varchar("status", { length: 20 }).notNull().default("pending"), // pending, waiting, completed, canceled
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const currencyLimits = pgTable("currency_limits", {
  id: serial("id").primaryKey(),
  currency: varchar("currency", { length: 20 }).notNull().unique(),
  minAmount: decimal("min_amount", { precision: 15, scale: 2 }).notNull().default("5"),
  maxAmount: decimal("max_amount", { precision: 15, scale: 2 }).notNull().default("10000"),
});

export const systemMessages = pgTable("system_messages", {
  id: serial("id").primaryKey(),
  messageType: varchar("message_type", { length: 50 }).notNull(), // order_submitted, payment_confirmed, order_completed, order_canceled
  subject: text("subject").notNull(),
  body: text("body").notNull(),
  isActive: boolean("is_active").notNull().default(true),
});

// Relations
export const ordersRelations = relations(orders, ({ one }) => ({
  fromCurrencyRate: one(exchangeRates, {
    fields: [orders.fromCurrency],
    references: [exchangeRates.fromCurrency],
  }),
}));

export const exchangeRatesRelations = relations(exchangeRates, ({ many }) => ({
  ordersFrom: many(orders),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  orderNumber: true,
  createdAt: true,
  updatedAt: true,
  status: true,
});

export const insertExchangeRateSchema = createInsertSchema(exchangeRates).omit({
  id: true,
  lastUpdated: true,
});

export const insertCurrencyLimitSchema = createInsertSchema(currencyLimits).omit({
  id: true,
});

export const insertSystemMessageSchema = createInsertSchema(systemMessages).omit({
  id: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;
export type InsertExchangeRate = z.infer<typeof insertExchangeRateSchema>;
export type ExchangeRate = typeof exchangeRates.$inferSelect;
export type InsertCurrencyLimit = z.infer<typeof insertCurrencyLimitSchema>;
export type CurrencyLimit = typeof currencyLimits.$inferSelect;
export type InsertSystemMessage = z.infer<typeof insertSystemMessageSchema>;
export type SystemMessage = typeof systemMessages.$inferSelect;
