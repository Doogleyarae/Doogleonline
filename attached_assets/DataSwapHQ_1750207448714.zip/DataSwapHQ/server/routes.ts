import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { insertOrderSchema, insertExchangeRateSchema, insertCurrencyLimitSchema, insertSystemMessageSchema } from "@shared/schema";
import { sendEmail } from "./services/email";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Exchange rates API
  app.get("/api/exchange-rates", async (req, res) => {
    try {
      const rates = await storage.getAllExchangeRates();
      res.json(rates);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch exchange rates" });
    }
  });

  app.get("/api/exchange-rate/:from/:to", async (req, res) => {
    try {
      const { from, to } = req.params;
      const rate = await storage.getExchangeRate(from.toUpperCase(), to.toUpperCase());
      if (!rate) {
        return res.status(404).json({ message: "Exchange rate not found" });
      }
      res.json(rate);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch exchange rate" });
    }
  });

  // Protected admin routes for exchange rates
  app.post("/api/admin/exchange-rates", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    try {
      const rateData = insertExchangeRateSchema.parse(req.body);
      const rate = await storage.upsertExchangeRate(rateData);
      res.json(rate);
    } catch (error) {
      res.status(400).json({ message: "Invalid exchange rate data" });
    }
  });

  // Currency limits API
  app.get("/api/currency-limits", async (req, res) => {
    try {
      const limits = await storage.getAllCurrencyLimits();
      res.json(limits);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch currency limits" });
    }
  });

  app.get("/api/currency-limit/:currency", async (req, res) => {
    try {
      const { currency } = req.params;
      const limit = await storage.getCurrencyLimit(currency.toUpperCase());
      if (!limit) {
        return res.status(404).json({ message: "Currency limit not found" });
      }
      res.json(limit);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch currency limit" });
    }
  });

  // Protected admin routes for currency limits
  app.post("/api/admin/currency-limits", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    try {
      const limitData = insertCurrencyLimitSchema.parse(req.body);
      const limit = await storage.upsertCurrencyLimit(limitData);
      res.json(limit);
    } catch (error) {
      res.status(400).json({ message: "Invalid currency limit data" });
    }
  });

  // Orders API
  app.post("/api/orders", async (req, res) => {
    try {
      const orderData = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder(orderData);
      
      // Send order submitted email
      try {
        await sendEmail({
          to: order.customerEmail,
          subject: "Order Submitted - Pending Confirmation",
          messageType: "order_submitted",
          orderData: order,
        });
      } catch (emailError) {
        console.error("Failed to send order submission email:", emailError);
      }
      
      res.status(201).json(order);
    } catch (error) {
      res.status(400).json({ message: "Invalid order data" });
    }
  });

  app.get("/api/orders/:orderNumber", async (req, res) => {
    try {
      const { orderNumber } = req.params;
      const order = await storage.getOrderByNumber(orderNumber);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      res.json(order);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch order" });
    }
  });

  // Payment confirmation endpoint
  app.post("/api/orders/:orderNumber/confirm-payment", async (req, res) => {
    try {
      const { orderNumber } = req.params;
      const order = await storage.getOrderByNumber(orderNumber);
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      if (order.status !== "pending") {
        return res.status(400).json({ message: "Order cannot be confirmed in current status" });
      }
      
      const updatedOrder = await storage.updateOrderStatus(order.id, "waiting");
      
      // Send payment confirmed email
      try {
        await sendEmail({
          to: order.customerEmail,
          subject: "Payment Confirmed - Waiting for Admin",
          messageType: "payment_confirmed",
          orderData: updatedOrder!,
        });
      } catch (emailError) {
        console.error("Failed to send payment confirmation email:", emailError);
      }
      
      res.json(updatedOrder);
    } catch (error) {
      res.status(500).json({ message: "Failed to confirm payment" });
    }
  });

  // Cancel order endpoint
  app.post("/api/orders/:orderNumber/cancel", async (req, res) => {
    try {
      const { orderNumber } = req.params;
      const order = await storage.getOrderByNumber(orderNumber);
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      if (order.status === "completed") {
        return res.status(400).json({ message: "Completed orders cannot be canceled" });
      }
      
      const updatedOrder = await storage.updateOrderStatus(order.id, "canceled");
      
      // Send order canceled email
      try {
        await sendEmail({
          to: order.customerEmail,
          subject: "Order Canceled",
          messageType: "order_canceled",
          orderData: updatedOrder!,
        });
      } catch (emailError) {
        console.error("Failed to send order cancellation email:", emailError);
      }
      
      res.json(updatedOrder);
    } catch (error) {
      res.status(500).json({ message: "Failed to cancel order" });
    }
  });

  // Protected admin routes for orders
  app.get("/api/admin/orders", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    try {
      const { search, status } = req.query;
      const orders = await storage.getOrders(
        search as string,
        status as string
      );
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.post("/api/admin/orders/:id/accept", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    try {
      const { id } = req.params;
      const order = await storage.getOrder(parseInt(id));
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      if (order.status !== "waiting") {
        return res.status(400).json({ message: "Order cannot be accepted in current status" });
      }
      
      const updatedOrder = await storage.updateOrderStatus(order.id, "completed");
      
      // Send order completed email
      try {
        await sendEmail({
          to: order.customerEmail,
          subject: "Order Completed Successfully",
          messageType: "order_completed",
          orderData: updatedOrder!,
        });
      } catch (emailError) {
        console.error("Failed to send order completion email:", emailError);
      }
      
      res.json(updatedOrder);
    } catch (error) {
      res.status(500).json({ message: "Failed to accept order" });
    }
  });

  app.post("/api/admin/orders/:id/cancel", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    try {
      const { id } = req.params;
      const order = await storage.getOrder(parseInt(id));
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      if (order.status === "completed") {
        return res.status(400).json({ message: "Completed orders cannot be canceled" });
      }
      
      const updatedOrder = await storage.updateOrderStatus(order.id, "canceled");
      
      // Send order canceled email
      try {
        await sendEmail({
          to: order.customerEmail,
          subject: "Order Canceled by Admin",
          messageType: "order_canceled",
          orderData: updatedOrder!,
        });
      } catch (emailError) {
        console.error("Failed to send order cancellation email:", emailError);
      }
      
      res.json(updatedOrder);
    } catch (error) {
      res.status(500).json({ message: "Failed to cancel order" });
    }
  });

  // System messages API (admin only)
  app.get("/api/admin/system-messages", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    try {
      const messages = await storage.getSystemMessages();
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch system messages" });
    }
  });

  app.post("/api/admin/system-messages", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    try {
      const messageData = insertSystemMessageSchema.parse(req.body);
      const message = await storage.upsertSystemMessage(messageData);
      res.json(message);
    } catch (error) {
      res.status(400).json({ message: "Invalid system message data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
