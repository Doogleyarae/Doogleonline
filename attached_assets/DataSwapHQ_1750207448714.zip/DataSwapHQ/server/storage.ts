import { 
  users, type User, type InsertUser,
  orders, type Order, type InsertOrder,
  exchangeRates, type ExchangeRate, type InsertExchangeRate,
  currencyLimits, type CurrencyLimit, type InsertCurrencyLimit,
  systemMessages, type SystemMessage, type InsertSystemMessage
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, like, or, and } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Order management
  getOrder(id: number): Promise<Order | undefined>;
  getOrderByNumber(orderNumber: string): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: number, status: string): Promise<Order | undefined>;
  getOrders(search?: string, status?: string): Promise<Order[]>;
  
  // Exchange rate management
  getExchangeRate(fromCurrency: string, toCurrency: string): Promise<ExchangeRate | undefined>;
  getAllExchangeRates(): Promise<ExchangeRate[]>;
  upsertExchangeRate(rate: InsertExchangeRate): Promise<ExchangeRate>;
  
  // Currency limits
  getCurrencyLimit(currency: string): Promise<CurrencyLimit | undefined>;
  getAllCurrencyLimits(): Promise<CurrencyLimit[]>;
  upsertCurrencyLimit(limit: InsertCurrencyLimit): Promise<CurrencyLimit>;
  
  // System messages
  getSystemMessages(): Promise<SystemMessage[]>;
  getSystemMessage(messageType: string): Promise<SystemMessage | undefined>;
  upsertSystemMessage(message: InsertSystemMessage): Promise<SystemMessage>;
  
  sessionStore: session.SessionStore;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.SessionStore;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getOrder(id: number): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    return order || undefined;
  }

  async getOrderByNumber(orderNumber: string): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.orderNumber, orderNumber));
    return order || undefined;
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    // Generate unique order number
    const orderNumber = `EX-${new Date().getFullYear()}-${Date.now().toString().slice(-6)}`;
    
    const [order] = await db
      .insert(orders)
      .values({
        ...insertOrder,
        orderNumber,
      })
      .returning();
    return order;
  }

  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const [order] = await db
      .update(orders)
      .set({ 
        status, 
        updatedAt: new Date() 
      })
      .where(eq(orders.id, id))
      .returning();
    return order || undefined;
  }

  async getOrders(search?: string, status?: string): Promise<Order[]> {
    let query = db.select().from(orders);
    
    const conditions = [];
    
    if (search) {
      conditions.push(
        or(
          like(orders.orderNumber, `%${search}%`),
          like(orders.customerName, `%${search}%`),
          like(orders.customerEmail, `%${search}%`),
          like(orders.paymentMethod, `%${search}%`)
        )
      );
    }
    
    if (status) {
      conditions.push(eq(orders.status, status));
    }
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }
    
    return await query.orderBy(desc(orders.createdAt));
  }

  async getExchangeRate(fromCurrency: string, toCurrency: string): Promise<ExchangeRate | undefined> {
    const [rate] = await db
      .select()
      .from(exchangeRates)
      .where(
        and(
          eq(exchangeRates.fromCurrency, fromCurrency),
          eq(exchangeRates.toCurrency, toCurrency)
        )
      );
    return rate || undefined;
  }

  async getAllExchangeRates(): Promise<ExchangeRate[]> {
    return await db.select().from(exchangeRates).orderBy(exchangeRates.fromCurrency, exchangeRates.toCurrency);
  }

  async upsertExchangeRate(rate: InsertExchangeRate): Promise<ExchangeRate> {
    const existing = await this.getExchangeRate(rate.fromCurrency, rate.toCurrency);
    
    if (existing) {
      const [updated] = await db
        .update(exchangeRates)
        .set({
          rate: rate.rate,
          lastUpdated: new Date(),
        })
        .where(
          and(
            eq(exchangeRates.fromCurrency, rate.fromCurrency),
            eq(exchangeRates.toCurrency, rate.toCurrency)
          )
        )
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(exchangeRates)
        .values(rate)
        .returning();
      return created;
    }
  }

  async getCurrencyLimit(currency: string): Promise<CurrencyLimit | undefined> {
    const [limit] = await db
      .select()
      .from(currencyLimits)
      .where(eq(currencyLimits.currency, currency));
    return limit || undefined;
  }

  async getAllCurrencyLimits(): Promise<CurrencyLimit[]> {
    return await db.select().from(currencyLimits).orderBy(currencyLimits.currency);
  }

  async upsertCurrencyLimit(limit: InsertCurrencyLimit): Promise<CurrencyLimit> {
    const existing = await this.getCurrencyLimit(limit.currency);
    
    if (existing) {
      const [updated] = await db
        .update(currencyLimits)
        .set(limit)
        .where(eq(currencyLimits.currency, limit.currency))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(currencyLimits)
        .values(limit)
        .returning();
      return created;
    }
  }

  async getSystemMessages(): Promise<SystemMessage[]> {
    return await db.select().from(systemMessages).where(eq(systemMessages.isActive, true));
  }

  async getSystemMessage(messageType: string): Promise<SystemMessage | undefined> {
    const [message] = await db
      .select()
      .from(systemMessages)
      .where(
        and(
          eq(systemMessages.messageType, messageType),
          eq(systemMessages.isActive, true)
        )
      );
    return message || undefined;
  }

  async upsertSystemMessage(message: InsertSystemMessage): Promise<SystemMessage> {
    const existing = await this.getSystemMessage(message.messageType);
    
    if (existing) {
      const [updated] = await db
        .update(systemMessages)
        .set(message)
        .where(eq(systemMessages.messageType, message.messageType))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(systemMessages)
        .values(message)
        .returning();
      return created;
    }
  }
}

export const storage = new DatabaseStorage();
