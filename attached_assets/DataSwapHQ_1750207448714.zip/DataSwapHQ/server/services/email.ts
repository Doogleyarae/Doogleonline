import { Resend } from "resend";
import { storage } from "../storage";
import type { Order } from "@shared/schema";

const resend = new Resend(process.env.RESEND_API_KEY);

interface EmailData {
  to: string;
  subject: string;
  messageType: string;
  orderData: Order;
}

export async function sendEmail({ to, subject, messageType, orderData }: EmailData) {
  try {
    // Get custom message template from database
    const systemMessage = await storage.getSystemMessage(messageType);
    
    let emailBody = "";
    
    if (systemMessage) {
      // Replace placeholders in the custom message
      emailBody = systemMessage.body
        .replace(/{{orderNumber}}/g, orderData.orderNumber)
        .replace(/{{customerName}}/g, orderData.customerName)
        .replace(/{{fromAmount}}/g, orderData.fromAmount)
        .replace(/{{fromCurrency}}/g, orderData.fromCurrency)
        .replace(/{{toAmount}}/g, orderData.toAmount)
        .replace(/{{toCurrency}}/g, orderData.toCurrency)
        .replace(/{{paymentMethod}}/g, orderData.paymentMethod)
        .replace(/{{status}}/g, orderData.status);
    } else {
      // Fallback to default templates
      emailBody = getDefaultEmailTemplate(messageType, orderData);
    }

    const htmlBody = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>${subject}</title>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #2563EB; color: white; padding: 20px; text-align: center; }
            .content { padding: 20px; background: #f9f9f9; }
            .order-details { background: white; padding: 15px; margin: 15px 0; border-radius: 5px; }
            .footer { text-align: center; padding: 20px; font-size: 12px; color: #666; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Doogle Online</h1>
              <p>Currency Exchange Service</p>
            </div>
            <div class="content">
              <h2>${subject}</h2>
              ${emailBody}
              <div class="order-details">
                <h3>Order Details</h3>
                <p><strong>Order ID:</strong> ${orderData.orderNumber}</p>
                <p><strong>Exchange:</strong> ${orderData.fromAmount} ${orderData.fromCurrency} → ${orderData.toAmount} ${orderData.toCurrency}</p>
                <p><strong>Payment Method:</strong> ${orderData.paymentMethod}</p>
                <p><strong>Status:</strong> ${orderData.status.toUpperCase()}</p>
                <p><strong>Created:</strong> ${new Date(orderData.createdAt).toLocaleString()}</p>
              </div>
            </div>
            <div class="footer">
              <p>© 2024 Doogle Online. All rights reserved.</p>
              <p>Contact us: support@doogleonline.com | +252 61 234 5678</p>
            </div>
          </div>
        </body>
      </html>
    `;

    await resend.emails.send({
      from: process.env.RESEND_FROM_EMAIL || "noreply@doogleonline.com",
      to,
      subject,
      html: htmlBody,
    });

    console.log(`Email sent successfully to ${to} for order ${orderData.orderNumber}`);
  } catch (error) {
    console.error("Failed to send email:", error);
    throw error;
  }
}

function getDefaultEmailTemplate(messageType: string, orderData: Order): string {
  switch (messageType) {
    case "order_submitted":
      return `
        <p>Dear ${orderData.customerName},</p>
        <p>Thank you for submitting your currency exchange order. Your order has been received and is currently pending payment confirmation.</p>
        <p>Please review the order details below and proceed with payment confirmation if everything looks correct.</p>
      `;
    
    case "payment_confirmed":
      return `
        <p>Dear ${orderData.customerName},</p>
        <p>Your payment has been confirmed and your order is now being reviewed by our admin team.</p>
        <p>Processing typically takes up to 15 minutes during business hours. You will receive another email once your order is completed.</p>
      `;
    
    case "order_completed":
      return `
        <p>Dear ${orderData.customerName},</p>
        <p>Great news! Your currency exchange order has been completed successfully.</p>
        <p>Your exchange of ${orderData.fromAmount} ${orderData.fromCurrency} to ${orderData.toAmount} ${orderData.toCurrency} has been processed.</p>
        <p>Thank you for choosing Doogle Online for your currency exchange needs.</p>
      `;
    
    case "order_canceled":
      return `
        <p>Dear ${orderData.customerName},</p>
        <p>We regret to inform you that your currency exchange order has been canceled.</p>
        <p>If you have any questions about this cancellation, please contact our support team.</p>
        <p>You can always submit a new exchange request on our website.</p>
      `;
    
    default:
      return `
        <p>Dear ${orderData.customerName},</p>
        <p>This is an update regarding your currency exchange order ${orderData.orderNumber}.</p>
      `;
  }
}
