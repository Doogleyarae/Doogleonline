import { storage } from "../storage";

// Common currency pairs with default rates for mobile money and crypto
const defaultRates = [
  { fromCurrency: "Zaad", toCurrency: "Sahal", rate: "1.00" },
  { fromCurrency: "Sahal", toCurrency: "Zaad", rate: "1.00" },
  { fromCurrency: "Zaad", toCurrency: "EVC Plus", rate: "1.00" },
  { fromCurrency: "EVC Plus", toCurrency: "Zaad", rate: "1.00" },
  { fromCurrency: "Zaad", toCurrency: "eDahab", rate: "1.00" },
  { fromCurrency: "eDahab", toCurrency: "Zaad", rate: "1.00" },
  { fromCurrency: "Zaad", toCurrency: "Premier Bank", rate: "1.00" },
  { fromCurrency: "Premier Bank", toCurrency: "Zaad", rate: "1.00" },
  { fromCurrency: "Zaad", toCurrency: "MoneyGo", rate: "1.00" },
  { fromCurrency: "MoneyGo", toCurrency: "Zaad", rate: "1.00" },
  { fromCurrency: "MoneyGo", toCurrency: "Sahal", rate: "1.00" },
  { fromCurrency: "Sahal", toCurrency: "MoneyGo", rate: "1.00" },
  { fromCurrency: "MoneyGo", toCurrency: "EVC Plus", rate: "1.00" },
  { fromCurrency: "EVC Plus", toCurrency: "MoneyGo", rate: "1.00" },
  { fromCurrency: "TRX", toCurrency: "TRC20", rate: "1.00" },
  { fromCurrency: "TRC20", toCurrency: "TRX", rate: "1.00" },
  { fromCurrency: "TRX", toCurrency: "PEB20", rate: "0.95" },
  { fromCurrency: "PEB20", toCurrency: "TRX", rate: "1.05" },
  { fromCurrency: "Zaad", toCurrency: "TRX", rate: "0.15" },
  { fromCurrency: "TRX", toCurrency: "Zaad", rate: "6.67" },
  { fromCurrency: "MoneyGo", toCurrency: "TRX", rate: "0.15" },
  { fromCurrency: "TRX", toCurrency: "MoneyGo", rate: "6.67" },
];

const defaultLimits = [
  { currency: "Zaad", minAmount: "10", maxAmount: "50000" },
  { currency: "Sahal", minAmount: "10", maxAmount: "50000" },
  { currency: "EVC Plus", minAmount: "10", maxAmount: "50000" },
  { currency: "eDahab", minAmount: "10", maxAmount: "50000" },
  { currency: "Premier Bank", minAmount: "100", maxAmount: "100000" },
  { currency: "MoneyGo", minAmount: "10", maxAmount: "50000" },
  { currency: "TRX", minAmount: "100", maxAmount: "1000000" },
  { currency: "TRC20", minAmount: "100", maxAmount: "1000000" },
  { currency: "PEB20", minAmount: "100", maxAmount: "1000000" },
];

const defaultMessages = [
  {
    messageType: "order_submitted",
    subject: "Order Submitted - Pending Confirmation",
    body: `<p>Dear {{customerName}},</p>
           <p>Thank you for submitting your currency exchange order {{orderNumber}}. Your order has been received and is currently pending payment confirmation.</p>
           <p>Please review the order details and proceed with payment confirmation if everything looks correct.</p>`,
    isActive: true,
  },
  {
    messageType: "payment_confirmed", 
    subject: "Payment Confirmed - Waiting for Admin",
    body: `<p>Dear {{customerName}},</p>
           <p>Your payment for order {{orderNumber}} has been confirmed and your order is now being reviewed by our admin team.</p>
           <p>Processing typically takes up to 15 minutes during business hours. You will receive another email once your order is completed.</p>`,
    isActive: true,
  },
  {
    messageType: "order_completed",
    subject: "Order Completed Successfully", 
    body: `<p>Dear {{customerName}},</p>
           <p>Great news! Your currency exchange order {{orderNumber}} has been completed successfully.</p>
           <p>Your exchange of {{fromAmount}} {{fromCurrency}} to {{toAmount}} {{toCurrency}} has been processed.</p>
           <p>Thank you for choosing Doogle Online for your currency exchange needs.</p>`,
    isActive: true,
  },
  {
    messageType: "order_canceled",
    subject: "Order Canceled",
    body: `<p>Dear {{customerName}},</p>
           <p>We regret to inform you that your currency exchange order {{orderNumber}} has been canceled.</p>
           <p>If you have any questions about this cancellation, please contact our support team.</p>
           <p>You can always submit a new exchange request on our website.</p>`,
    isActive: true,
  },
];

export async function initializeDefaultData() {
  try {
    console.log("Initializing default exchange rates, limits, and messages...");

    // Initialize default exchange rates
    for (const rate of defaultRates) {
      await storage.upsertExchangeRate(rate);
    }

    // Initialize default currency limits
    for (const limit of defaultLimits) {
      await storage.upsertCurrencyLimit(limit);
    }

    // Initialize default system messages
    for (const message of defaultMessages) {
      await storage.upsertSystemMessage(message);
    }

    console.log("Default data initialization completed successfully.");
  } catch (error) {
    console.error("Failed to initialize default data:", error);
  }
}
