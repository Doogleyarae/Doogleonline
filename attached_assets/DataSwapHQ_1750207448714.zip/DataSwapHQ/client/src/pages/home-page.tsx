import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { SimpleExchangeForm } from "@/components/simple-exchange-form";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-neutral-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-neutral-900 mb-2">Currency Exchange</h2>
          <p className="text-neutral-500 text-lg">Fast, secure, and reliable currency exchange service</p>
        </div>

        <SimpleExchangeForm />
      </main>

      <Footer />
    </div>
  );
}
