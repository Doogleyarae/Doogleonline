import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Clock, Check, X, AlertCircle, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import type { Order } from "@shared/schema";

export default function OrderStatus() {
  const { orderNumber } = useParams<{ orderNumber: string }>();

  const { data: order, isLoading, error } = useQuery<Order>({
    queryKey: [`/api/orders/${orderNumber}`],
    enabled: !!orderNumber,
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="h-8 w-8 text-yellow-600" />;
      case "waiting":
        return <Clock className="h-8 w-8 text-blue-600" />;
      case "completed":
        return <Check className="h-8 w-8 text-green-600" />;
      case "canceled":
        return <X className="h-8 w-8 text-red-600" />;
      default:
        return <AlertCircle className="h-8 w-8 text-gray-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "waiting":
        return "bg-blue-100 text-blue-800";
      case "completed":
        return "bg-green-100 text-green-800";
      case "canceled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusMessage = (status: string) => {
    switch (status) {
      case "pending":
        return "Your order has been submitted and is awaiting payment confirmation.";
      case "waiting":
        return "Payment confirmed. Waiting for admin review and processing.";
      case "completed":
        return "Your order has been completed successfully!";
      case "canceled":
        return "This order has been canceled.";
      default:
        return "Unknown status";
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-neutral-50">
        <Header />
        <main className="max-w-4xl mx-auto px-4 py-8">
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="min-h-screen bg-neutral-50">
        <Header />
        <main className="max-w-4xl mx-auto px-4 py-8">
          <Card className="text-center">
            <CardContent className="py-12">
              <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-neutral-900 mb-2">Order Not Found</h2>
              <p className="text-neutral-500 mb-6">
                The order number you provided could not be found. Please check the order number and try again.
              </p>
              <Link href="/">
                <Button>
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Exchange
                </Button>
              </Link>
            </CardContent>
          </Card>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <Header />

      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-6">
          <Link href="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Exchange
            </Button>
          </Link>
        </div>

        <div className="text-center mb-8">
          <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-white shadow-sm mb-4">
            {getStatusIcon(order.status)}
          </div>
          <h1 className="text-3xl font-bold text-neutral-900 mb-2">Order Status</h1>
          <p className="text-neutral-500 text-lg">{getStatusMessage(order.status)}</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Order Details */}
          <Card>
            <CardHeader>
              <CardTitle>Order Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-neutral-500">Order ID</Label>
                  <p className="font-mono text-neutral-900">{order.orderNumber}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-neutral-500">Status</Label>
                  <div className="mt-1">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                      {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                    </span>
                  </div>
                </div>
                <div>
                  <Label className="text-sm font-medium text-neutral-500">Exchange Amount</Label>
                  <p className="font-semibold text-neutral-900">
                    {order.fromAmount} {order.fromCurrency} → {order.toAmount} {order.toCurrency}
                  </p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-neutral-500">Exchange Rate</Label>
                  <p className="text-neutral-900">{order.exchangeRate}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-neutral-500">Payment Method</Label>
                  <p className="text-neutral-900">{order.paymentMethod}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-neutral-500">Created</Label>
                  <p className="text-neutral-900">{new Date(order.createdAt).toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Customer Information */}
          <Card>
            <CardHeader>
              <CardTitle>Customer Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-sm font-medium text-neutral-500">Full Name</Label>
                <p className="text-neutral-900">{order.customerName}</p>
              </div>
              <div>
                <Label className="text-sm font-medium text-neutral-500">Email</Label>
                <p className="text-neutral-900">{order.customerEmail}</p>
              </div>
              <div>
                <Label className="text-sm font-medium text-neutral-500">Phone</Label>
                <p className="text-neutral-900">{order.customerPhone}</p>
              </div>
              <div>
                <Label className="text-sm font-medium text-neutral-500">Account/Wallet</Label>
                <p className="text-neutral-900">{order.customerAccount}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Progress Steps */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Order Progress</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center">
                <div className="flex-shrink-0 h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
                  <Check className="h-4 w-4 text-green-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-neutral-900">Order Submitted</p>
                  <p className="text-xs text-neutral-500">Your exchange request has been received</p>
                </div>
              </div>

              <div className="flex items-center">
                <div className={`flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center ${
                  ["waiting", "completed"].includes(order.status) 
                    ? "bg-green-100" 
                    : order.status === "canceled" 
                    ? "bg-red-100" 
                    : "bg-neutral-200"
                }`}>
                  {["waiting", "completed"].includes(order.status) ? (
                    <Check className="h-4 w-4 text-green-600" />
                  ) : order.status === "canceled" ? (
                    <X className="h-4 w-4 text-red-600" />
                  ) : (
                    <Clock className="h-4 w-4 text-neutral-400" />
                  )}
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-neutral-900">Payment Confirmed</p>
                  <p className="text-xs text-neutral-500">Payment method has been verified</p>
                </div>
              </div>

              <div className="flex items-center">
                <div className={`flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center ${
                  order.status === "completed" 
                    ? "bg-green-100" 
                    : order.status === "waiting" 
                    ? "bg-blue-100" 
                    : order.status === "canceled" 
                    ? "bg-red-100" 
                    : "bg-neutral-200"
                }`}>
                  {order.status === "completed" ? (
                    <Check className="h-4 w-4 text-green-600" />
                  ) : order.status === "waiting" ? (
                    <Clock className="h-4 w-4 text-blue-600" />
                  ) : order.status === "canceled" ? (
                    <X className="h-4 w-4 text-red-600" />
                  ) : (
                    <Clock className="h-4 w-4 text-neutral-400" />
                  )}
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-neutral-900">
                    {order.status === "waiting" ? "Admin Review (In Progress)" : "Admin Review"}
                  </p>
                  <p className="text-xs text-neutral-500">
                    {order.status === "waiting" 
                      ? "Currently being reviewed by admin (up to 15 minutes)" 
                      : "Waiting for admin confirmation"}
                  </p>
                </div>
              </div>

              <div className={`flex items-center ${order.status !== "completed" ? "opacity-50" : ""}`}>
                <div className={`flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center ${
                  order.status === "completed" ? "bg-green-100" : "bg-neutral-200"
                }`}>
                  <Check className={`h-4 w-4 ${order.status === "completed" ? "text-green-600" : "text-neutral-400"}`} />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-neutral-900">Order Completed</p>
                  <p className="text-xs text-neutral-500">Exchange has been processed and completed</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Security Notice */}
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mt-8">
          <div className="flex items-start">
            <AlertCircle className="h-5 w-5 text-amber-600 mt-0.5 mr-3 flex-shrink-0" />
            <div>
              <h4 className="text-sm font-semibold text-amber-800">Important Information</h4>
              <p className="text-xs text-amber-700 mt-1">
                Keep this order number safe for future reference. Processing times may vary but typically complete within 15 minutes during business hours.
              </p>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}

function Label({ className, children }: { className?: string; children: React.ReactNode }) {
  return <div className={className}>{children}</div>;
}
