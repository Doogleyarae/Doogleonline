import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Loader2, LogOut, Search, Check, X, TrendingUp, Users, DollarSign, Copy, Edit, Save, Plus, Trash2, Wallet, Contact } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import type { Order, ExchangeRate } from "@shared/schema";

export default function AdminDashboard() {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [editingRate, setEditingRate] = useState<number | null>(null);
  const [editingWallet, setEditingWallet] = useState<number | null>(null);
  const [newRateForm, setNewRateForm] = useState({ fromCurrency: "", toCurrency: "", rate: "" });
  const [balances, setBalances] = useState([
    { currency: "Zaad", balance: "125,000" },
    { currency: "Sahal", balance: "85,500" },
    { currency: "EVC Plus", balance: "95,250" },
    { currency: "eDahab", balance: "110,750" },
    { currency: "Premier Bank", balance: "2,500,000" },
    { currency: "MoneyGo", balance: "75,400" },
    { currency: "TRX", balance: "50,000" },
    { currency: "TRC20", balance: "25,000" },
    { currency: "PEB20", balance: "15,000" },
  ]);
  const [contacts, setContacts] = useState([
    { id: 1, name: "Ahmed Hassan", phone: "+252615123456", currency: "Zaad", account: "615123456" },
    { id: 2, name: "Fatima Omar", phone: "+252617654321", currency: "Sahal", account: "617654321" },
    { id: 3, name: "Mohamed Ali", phone: "+252619876543", currency: "EVC Plus", account: "619876543" },
  ]);
  const [wallets, setWallets] = useState([
    { id: 1, name: "Zaad Wallet", currency: "Zaad", address: "615123456", balance: "125,000" },
    { id: 2, name: "Sahal Wallet", currency: "Sahal", address: "617654321", balance: "85,500" },
    { id: 3, name: "EVC Plus Wallet", currency: "EVC Plus", address: "619876543", balance: "95,250" },
    { id: 4, name: "eDahab Wallet", currency: "eDahab", address: "614987321", balance: "110,750" },
    { id: 5, name: "Premier Bank Account", currency: "Premier Bank", address: "PB2025001234", balance: "2,500,000" },
    { id: 6, name: "MoneyGo Wallet", currency: "MoneyGo", address: "612345678", balance: "75,400" },
    { id: 7, name: "TRX Wallet", currency: "TRX", address: "TRXWallet123456789", balance: "50,000" },
    { id: 8, name: "TRC20 Wallet", currency: "TRC20", address: "TRC20Address987654", balance: "25,000" },
    { id: 9, name: "PEB20 Wallet", currency: "PEB20", address: "PEB20Wallet555888", balance: "15,000" },
  ]);

  const { data: orders = [], isLoading: ordersLoading } = useQuery<Order[]>({
    queryKey: ["/api/admin/orders", searchTerm, statusFilter],
  });

  const { data: exchangeRates = [], isLoading: ratesLoading } = useQuery<ExchangeRate[]>({
    queryKey: ["/api/exchange-rates"],
  });



  const acceptOrderMutation = useMutation({
    mutationFn: async (orderId: number) => {
      await apiRequest("POST", `/api/admin/orders/${orderId}/accept`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/orders"] });
      toast({
        title: "Order Accepted",
        description: "Order has been successfully accepted and completed.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const cancelOrderMutation = useMutation({
    mutationFn: async (orderId: number) => {
      await apiRequest("POST", `/api/admin/orders/${orderId}/cancel`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/orders"] });
      toast({
        title: "Order Canceled",
        description: "Order has been canceled.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateRateMutation = useMutation({
    mutationFn: async (data: { fromCurrency: string; toCurrency: string; rate: string }) => {
      await apiRequest("POST", "/api/admin/exchange-rates", {
        fromCurrency: data.fromCurrency,
        toCurrency: data.toCurrency,
        rate: data.rate,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/exchange-rates"] });
      toast({
        title: "Exchange Rate Updated",
        description: "Exchange rate has been successfully updated.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const copyToClipboard = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: `${label} copied to clipboard`,
      });
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Could not copy to clipboard",
        variant: "destructive",
      });
    }
  };

  const updateWallet = (walletId: number, field: string, value: string) => {
    setWallets(prev => prev.map(wallet => 
      wallet.id === walletId ? { ...wallet, [field]: value } : wallet
    ));
    setEditingWallet(null);
    toast({
      title: "Wallet Updated",
      description: "Wallet information has been updated successfully.",
    });
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "pending":
        return "secondary";
      case "waiting":
        return "default";
      case "completed":
        return "default";
      case "canceled":
        return "destructive";
      default:
        return "secondary";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "waiting":
        return "bg-blue-100 text-blue-800";
      case "completed":
        return "bg-green-100 text-green-800";
      case "canceled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const pendingOrders = orders.filter(order => order.status === "pending").length;
  const waitingOrders = orders.filter(order => order.status === "waiting").length;
  const completedOrders = orders.filter(order => order.status === "completed").length;

  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-neutral-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-primary">Doogle Online</h1>
              <span className="ml-4 text-sm text-neutral-500">Admin Dashboard</span>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-neutral-700">Welcome, {user?.username}</span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.location.href = '/'}
              >
                Back to Website
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => logoutMutation.mutate()}
                disabled={logoutMutation.isPending}
              >
                {logoutMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <LogOut className="h-4 w-4" />
                )}
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-2 bg-yellow-100 rounded-lg">
                  <Users className="h-5 w-5 text-yellow-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-neutral-500">Pending Orders</p>
                  <p className="text-2xl font-semibold text-neutral-900">{pendingOrders}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <TrendingUp className="h-5 w-5 text-blue-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-neutral-500">Waiting Orders</p>
                  <p className="text-2xl font-semibold text-neutral-900">{waitingOrders}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-2 bg-green-100 rounded-lg">
                  <Check className="h-5 w-5 text-green-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-neutral-500">Completed Orders</p>
                  <p className="text-2xl font-semibold text-neutral-900">{completedOrders}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <DollarSign className="h-5 w-5 text-primary" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-neutral-500">Total Orders</p>
                  <p className="text-2xl font-semibold text-neutral-900">{orders.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="orders" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="orders">Orders</TabsTrigger>
            <TabsTrigger value="rates">Exchange Rates</TabsTrigger>
            <TabsTrigger value="balance">Balance</TabsTrigger>
            <TabsTrigger value="contacts">Contacts</TabsTrigger>
            <TabsTrigger value="wallets">My Wallets</TabsTrigger>
          </TabsList>

          <TabsContent value="orders">
            <Card>
              <CardHeader>
                <CardTitle>Orders Management</CardTitle>
                <div className="flex gap-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-neutral-400" />
                    <Input
                      placeholder="Search orders by ID, customer, email..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <select 
                    value={statusFilter} 
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="flex h-10 w-48 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                  >
                    <option value="">All Statuses</option>
                    <option value="pending">Pending</option>
                    <option value="waiting">Waiting</option>
                    <option value="completed">Completed</option>
                    <option value="canceled">Canceled</option>
                  </select>
                </div>
              </CardHeader>
              <CardContent>
                {ordersLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin" />
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Order ID</TableHead>
                        <TableHead>Customer</TableHead>
                        <TableHead>Exchange</TableHead>
                        <TableHead>Payment Method</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Created</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {orders.map((order) => (
                        <TableRow key={order.id}>
                          <TableCell className="font-mono">{order.orderNumber}</TableCell>
                          <TableCell>
                            <div>
                              <p className="font-medium">{order.customerName}</p>
                              <p className="text-sm text-neutral-500">{order.customerEmail}</p>
                            </div>
                          </TableCell>
                          <TableCell>
                            {order.fromAmount} {order.fromCurrency} → {order.toAmount} {order.toCurrency}
                          </TableCell>
                          <TableCell>{order.paymentMethod}</TableCell>
                          <TableCell>
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                              {order.status}
                            </span>
                          </TableCell>
                          <TableCell>{new Date(order.createdAt).toLocaleDateString()}</TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              {order.status === "waiting" && (
                                <Button
                                  size="sm"
                                  onClick={() => acceptOrderMutation.mutate(order.id)}
                                  disabled={acceptOrderMutation.isPending}
                                >
                                  <Check className="h-4 w-4 mr-1" />
                                  Accept
                                </Button>
                              )}
                              {order.status !== "completed" && order.status !== "canceled" && (
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => cancelOrderMutation.mutate(order.id)}
                                  disabled={cancelOrderMutation.isPending}
                                >
                                  <X className="h-4 w-4 mr-1" />
                                  Cancel
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="rates">
            <Card>
              <CardHeader>
                <CardTitle>Exchange Rates Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Add New Exchange Rate Form */}
                  <Card className="p-4 bg-gray-50">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                      <div>
                        <Label htmlFor="fromCurrency">From Currency</Label>
                        <select
                          id="fromCurrency"
                          value={newRateForm.fromCurrency}
                          onChange={(e) => setNewRateForm(prev => ({ ...prev, fromCurrency: e.target.value }))}
                          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                        >
                          <option value="">Select currency</option>
                          <option value="Zaad">Zaad</option>
                          <option value="Sahal">Sahal</option>
                          <option value="EVC Plus">EVC Plus</option>
                          <option value="eDahab">eDahab</option>
                          <option value="Premier Bank">Premier Bank</option>
                          <option value="MoneyGo">MoneyGo</option>
                          <option value="TRX">TRX</option>
                          <option value="TRC20">TRC20</option>
                          <option value="PEB20">PEB20</option>
                        </select>
                      </div>
                      
                      <div>
                        <Label htmlFor="toCurrency">To Currency</Label>
                        <select
                          id="toCurrency"
                          value={newRateForm.toCurrency}
                          onChange={(e) => setNewRateForm(prev => ({ ...prev, toCurrency: e.target.value }))}
                          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                        >
                          <option value="">Select currency</option>
                          <option value="Zaad">Zaad</option>
                          <option value="Sahal">Sahal</option>
                          <option value="EVC Plus">EVC Plus</option>
                          <option value="eDahab">eDahab</option>
                          <option value="Premier Bank">Premier Bank</option>
                          <option value="MoneyGo">MoneyGo</option>
                          <option value="TRX">TRX</option>
                          <option value="TRC20">TRC20</option>
                          <option value="PEB20">PEB20</option>
                        </select>
                      </div>
                      
                      <div>
                        <Label htmlFor="rate">Exchange Rate</Label>
                        <Input
                          id="rate"
                          type="number"
                          step="0.000001"
                          placeholder="Enter rate"
                          value={newRateForm.rate}
                          onChange={(e) => setNewRateForm(prev => ({ ...prev, rate: e.target.value }))}
                        />
                      </div>
                      
                      <Button
                        onClick={() => {
                          if (newRateForm.fromCurrency && newRateForm.toCurrency && newRateForm.rate) {
                            updateRateMutation.mutate(newRateForm);
                            setNewRateForm({ fromCurrency: "", toCurrency: "", rate: "" });
                          }
                        }}
                        disabled={!newRateForm.fromCurrency || !newRateForm.toCurrency || !newRateForm.rate || updateRateMutation.isPending}
                      >
                        {updateRateMutation.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        ) : (
                          <Plus className="h-4 w-4 mr-2" />
                        )}
                        Add Rate
                      </Button>
                    </div>
                  </Card>

                  {/* Exchange Rates Table */}
                  {ratesLoading ? (
                    <div className="flex items-center justify-center py-8">
                      <Loader2 className="h-8 w-8 animate-spin" />
                    </div>
                  ) : exchangeRates.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <p>No exchange rates configured yet.</p>
                      <p className="text-sm">Use the form above to add your first exchange rate.</p>
                    </div>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>From Currency</TableHead>
                          <TableHead>To Currency</TableHead>
                          <TableHead>Rate</TableHead>
                          <TableHead>Last Updated</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {exchangeRates.map((rate) => (
                          <TableRow key={rate.id}>
                            <TableCell className="font-medium">{rate.fromCurrency}</TableCell>
                            <TableCell className="font-medium">{rate.toCurrency}</TableCell>
                            <TableCell>
                              {editingRate === rate.id ? (
                                <Input
                                  type="number"
                                  step="0.000001"
                                  defaultValue={rate.rate}
                                  className="w-32"
                                  onKeyPress={(e) => {
                                    if (e.key === 'Enter') {
                                      const newRate = (e.target as HTMLInputElement).value;
                                      updateRateMutation.mutate({
                                        fromCurrency: rate.fromCurrency,
                                        toCurrency: rate.toCurrency,
                                        rate: newRate
                                      });
                                    }
                                  }}
                                />
                              ) : (
                                <span className="font-mono">{rate.rate}</span>
                              )}
                            </TableCell>
                            <TableCell className="text-sm text-gray-500">
                              {new Date(rate.lastUpdated).toLocaleString()}
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                {editingRate === rate.id ? (
                                  <Button 
                                    size="sm" 
                                    variant="outline"
                                    onClick={() => setEditingRate(null)}
                                  >
                                    <X className="h-4 w-4" />
                                  </Button>
                                ) : (
                                  <Button 
                                    size="sm" 
                                    variant="outline"
                                    onClick={() => setEditingRate(rate.id)}
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                )}
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => copyToClipboard(rate.rate, "Exchange rate")}
                                >
                                  <Copy className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="balance">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Balance Management
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {balances.map((balance, index) => (
                    <Card key={index} className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold">{balance.currency}</h3>
                          <p className="text-2xl font-bold text-green-600">{balance.balance}</p>
                        </div>
                        <div className="text-right">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => copyToClipboard(balance.balance, `${balance.currency} balance`)}
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="contacts">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Contact className="h-5 w-5" />
                  Contacts Management
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Phone</TableHead>
                      <TableHead>Currency</TableHead>
                      <TableHead>Account</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {contacts.map((contact) => (
                      <TableRow key={contact.id}>
                        <TableCell className="font-medium">{contact.name}</TableCell>
                        <TableCell>{contact.phone}</TableCell>
                        <TableCell>{contact.currency}</TableCell>
                        <TableCell>{contact.account}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => copyToClipboard(contact.phone, "Phone number")}
                            >
                              <Copy className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <Edit className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="wallets">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wallet className="h-5 w-5" />
                  My Wallets
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {wallets.map((wallet) => (
                    <Card key={wallet.id} className="p-6">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <h3 className="text-lg font-semibold">{wallet.name}</h3>
                          <Badge variant="secondary">{wallet.currency}</Badge>
                        </div>
                        
                        <div className="space-y-2">
                          <Label className="text-sm font-medium">Wallet Address</Label>
                          <div className="flex items-center gap-2">
                            {editingWallet === wallet.id ? (
                              <Input 
                                defaultValue={wallet.address}
                                className="font-mono text-sm"
                                onKeyPress={(e) => {
                                  if (e.key === 'Enter') {
                                    const newAddress = (e.target as HTMLInputElement).value;
                                    updateWallet(wallet.id, 'address', newAddress);
                                  }
                                }}
                                onBlur={(e) => {
                                  const newAddress = e.target.value;
                                  updateWallet(wallet.id, 'address', newAddress);
                                }}
                              />
                            ) : (
                              <Input 
                                value={wallet.address} 
                                readOnly 
                                className="font-mono text-sm"
                              />
                            )}
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => copyToClipboard(wallet.address, "Wallet address")}
                            >
                              <Copy className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label className="text-sm font-medium">Balance</Label>
                          <div className="flex items-center gap-2">
                            {editingWallet === wallet.id ? (
                              <Input 
                                defaultValue={wallet.balance}
                                className="font-mono text-sm font-bold text-green-600"
                                onKeyPress={(e) => {
                                  if (e.key === 'Enter') {
                                    const newBalance = (e.target as HTMLInputElement).value;
                                    updateWallet(wallet.id, 'balance', newBalance);
                                  }
                                }}
                                onBlur={(e) => {
                                  const newBalance = e.target.value;
                                  updateWallet(wallet.id, 'balance', newBalance);
                                }}
                              />
                            ) : (
                              <Input 
                                value={wallet.balance} 
                                readOnly 
                                className="font-mono text-sm font-bold text-green-600"
                              />
                            )}
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => copyToClipboard(wallet.balance, "Balance")}
                            >
                              <Copy className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>

                        <div className="flex gap-2 pt-2">
                          {editingWallet === wallet.id ? (
                            <>
                              <Button 
                                size="sm" 
                                variant="outline" 
                                className="flex-1"
                                onClick={() => setEditingWallet(null)}
                              >
                                <X className="h-4 w-4 mr-2" />
                                Cancel
                              </Button>
                              <Button 
                                size="sm" 
                                variant="default" 
                                className="flex-1"
                                onClick={() => setEditingWallet(null)}
                              >
                                <Save className="h-4 w-4 mr-2" />
                                Save
                              </Button>
                            </>
                          ) : (
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="flex-1"
                              onClick={() => setEditingWallet(wallet.id)}
                            >
                              <Edit className="h-4 w-4 mr-2" />
                              Edit
                            </Button>
                          )}
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
