import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { RefreshCw, Layers, Shield, University, Smartphone, Wallet, CreditCard, Banknote } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertOrderSchema, type ExchangeRate, type CurrencyLimit } from "@shared/schema";
import { z } from "zod";
import { useLocation } from "wouter";

const currencies = [
  { code: "Zaad", name: "Zaad" },
  { code: "Sahal", name: "Sahal" },
  { code: "EVC Plus", name: "EVC Plus" },
  { code: "eDahab", name: "eDahab" },
  { code: "Premier Bank", name: "Premier Bank" },
  { code: "MoneyGo", name: "MoneyGo" },
  { code: "TRX", name: "TRX" },
  { code: "TRC20", name: "TRC20" },
  { code: "PEB20", name: "PEB20" },
];

const paymentMethods = [
  { id: "Premier Bank", name: "Premier Bank", icon: University },
  { id: "Zaad", name: "Zaad", icon: Smartphone },
  { id: "Sahal", name: "Sahal", icon: Wallet },
  { id: "EVC Plus", name: "EVC Plus", icon: CreditCard },
  { id: "eDahab", name: "eDahab", icon: Banknote },
];

const formSchema = insertOrderSchema.extend({
  acceptTerms: z.boolean().refine(val => val === true, {
    message: "You must accept the terms and conditions",
  }),
}).omit({ paymentMethod: true }).extend({
  paymentMethod: z.string().optional().default("Online"),
});

type FormData = z.infer<typeof formSchema>;

export function SimpleExchangeForm() {
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  const [orderNumber, setOrderNumber] = useState("");
  const { toast } = useToast();
  const [, navigate] = useLocation();

  const { data: exchangeRates = [] } = useQuery<ExchangeRate[]>({
    queryKey: ["/api/exchange-rates"],
  });

  const { data: currencyLimits = [] } = useQuery<CurrencyLimit[]>({
    queryKey: ["/api/currency-limits"],
  });

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    getValues,
    reset,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      customerName: "",
      customerPhone: "",
      customerEmail: "",
      customerAccount: "",
      fromCurrency: "",
      toCurrency: "",
      fromAmount: "",
      toAmount: "",
      exchangeRate: "",
      paymentMethod: "Online",
      acceptTerms: false,
    },
  });

  const fromCurrency = watch("fromCurrency");
  const toCurrency = watch("toCurrency");
  const fromAmount = watch("fromAmount");

  // Calculate converted amount when currencies or amount changes
  const calculateConversion = () => {
    if (!fromCurrency || !toCurrency || !fromAmount) return;
    
    const rate = exchangeRates.find(
      r => r.fromCurrency === fromCurrency && r.toCurrency === toCurrency
    );
    
    if (rate) {
      const amount = parseFloat(fromAmount);
      const convertedAmount = (amount * parseFloat(rate.rate)).toFixed(2);
      setValue("toAmount", convertedAmount);
      setValue("exchangeRate", rate.rate);
    }
  };

  useEffect(() => {
    calculateConversion();
  }, [fromCurrency, toCurrency, fromAmount, exchangeRates]);

  const getCurrentRate = () => {
    if (!fromCurrency || !toCurrency) return null;
    return exchangeRates.find(
      r => r.fromCurrency === fromCurrency && r.toCurrency === toCurrency
    );
  };

  const getCurrencyLimit = (currency: string) => {
    return currencyLimits.find(l => l.currency === currency);
  };

  const switchCurrencies = () => {
    const currentFrom = getValues("fromCurrency");
    const currentTo = getValues("toCurrency");
    
    setValue("fromCurrency", currentTo);
    setValue("toCurrency", currentFrom);
    setValue("fromAmount", "");
    setValue("toAmount", "");
  };

  const createOrderMutation = useMutation({
    mutationFn: async (data: Omit<FormData, "acceptTerms">) => {
      const res = await apiRequest("POST", "/api/orders", data);
      return await res.json();
    },
    onSuccess: (order) => {
      setOrderNumber(order.orderNumber);
      setShowConfirmation(false);
      setShowSuccessDialog(true);
      reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const confirmPaymentMutation = useMutation({
    mutationFn: async (orderNumber: string) => {
      await apiRequest("POST", `/api/orders/${orderNumber}/confirm-payment`);
    },
    onSuccess: () => {
      navigate(`/order-status/${orderNumber}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const cancelOrderMutation = useMutation({
    mutationFn: async (orderNumber: string) => {
      await apiRequest("POST", `/api/orders/${orderNumber}/cancel`);
    },
    onSuccess: () => {
      setShowSuccessDialog(false);
      toast({
        title: "Order Canceled",
        description: "Your order has been canceled successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    const { acceptTerms, ...orderData } = data;
    setShowConfirmation(true);
  };

  const handleConfirmPayment = () => {
    const formData = getValues();
    const { acceptTerms, ...orderData } = formData;
    createOrderMutation.mutate(orderData);
  };

  const handleConfirmPaymentInDialog = () => {
    confirmPaymentMutation.mutate(orderNumber);
  };

  const handleCancelOrder = () => {
    cancelOrderMutation.mutate(orderNumber);
  };

  const currentRate = getCurrentRate();
  const fromLimit = fromCurrency ? getCurrencyLimit(fromCurrency) : null;

  return (
    <>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Exchange Calculator Section */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl font-semibold text-neutral-900">Exchange Calculator</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                {/* Currency Exchange Form */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="fromCurrency">From Currency</Label>
                    <select 
                      {...register("fromCurrency")}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <option value="">Select currency</option>
                      {currencies.map((currency) => (
                        <option key={currency.code} value={currency.code}>
                          {currency.code} - {currency.name}
                        </option>
                      ))}
                    </select>
                    {errors.fromCurrency && (
                      <p className="text-sm text-red-500 mt-1">{errors.fromCurrency.message}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="fromAmount">Amount</Label>
                    <div className="relative">
                      <span className="absolute left-3 top-3 text-neutral-500">$</span>
                      <Input
                        {...register("fromAmount")}
                        type="number"
                        placeholder="0.00"
                        className="pl-8"
                        min={fromLimit?.minAmount || 5}
                        max={fromLimit?.maxAmount || 10000}
                      />
                    </div>
                    {fromLimit && (
                      <p className="text-xs text-neutral-500 mt-1">
                        Min: ${fromLimit.minAmount} | Max: ${fromLimit.maxAmount}
                      </p>
                    )}
                    {errors.fromAmount && (
                      <p className="text-sm text-red-500 mt-1">{errors.fromAmount.message}</p>
                    )}
                  </div>
                </div>

                {/* Exchange Icon */}
                <div className="flex justify-center">
                  <Button
                    type="button"
                    size="icon"
                    onClick={switchCurrencies}
                    className="rounded-full"
                  >
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                </div>

                {/* To Currency Section */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="toCurrency">To Currency</Label>
                    <select 
                      {...register("toCurrency")}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <option value="">Select currency</option>
                      {currencies.map((currency) => (
                        <option key={currency.code} value={currency.code}>
                          {currency.code} - {currency.name}
                        </option>
                      ))}
                    </select>
                    {errors.toCurrency && (
                      <p className="text-sm text-red-500 mt-1">{errors.toCurrency.message}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="toAmount">Converted Amount</Label>
                    <Input
                      {...register("toAmount")}
                      readOnly
                      placeholder="0.00"
                      className="bg-neutral-50 font-semibold"
                    />
                    <p className="text-xs text-neutral-500 mt-1">Auto-calculated amount</p>
                  </div>
                </div>

                {/* Exchange Rate Display */}
                {currentRate && (
                  <div className="bg-neutral-50 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-neutral-700">Current Exchange Rate:</span>
                      <span className="text-lg font-semibold text-primary">
                        1 {fromCurrency} = {currentRate.rate} {toCurrency}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-500 mt-1">
                      Last updated: {new Date(currentRate.lastUpdated).toLocaleString()}
                    </p>
                  </div>
                )}

                {/* User Information Section */}
                <div className="border-t pt-6">
                  <h3 className="text-lg font-semibold text-neutral-900 mb-4">Your Information</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="customerName">Full Name</Label>
                      <Input {...register("customerName")} placeholder="Enter your full name" />
                      {errors.customerName && (
                        <p className="text-sm text-red-500 mt-1">{errors.customerName.message}</p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="customerPhone">Phone Number</Label>
                      <Input {...register("customerPhone")} placeholder="+252 61 234 5678" />
                      {errors.customerPhone && (
                        <p className="text-sm text-red-500 mt-1">{errors.customerPhone.message}</p>
                      )}
                    </div>
                  </div>

                  <div className="mt-4">
                    <Label htmlFor="customerEmail">Email Address</Label>
                    <Input {...register("customerEmail")} type="email" placeholder="your.email@example.com" />
                    {errors.customerEmail && (
                      <p className="text-sm text-red-500 mt-1">{errors.customerEmail.message}</p>
                    )}
                  </div>

                  <div className="mt-4">
                    <Label htmlFor="customerAccount">Account/Wallet Number</Label>
                    <Input {...register("customerAccount")} placeholder="Enter your account or wallet number" />
                    {errors.customerAccount && (
                      <p className="text-sm text-red-500 mt-1">{errors.customerAccount.message}</p>
                    )}
                  </div>
                </div>



                {/* Terms and Submit */}
                <div className="border-t pt-6">
                  <div className="flex items-start space-x-3 mb-4">
                    <Checkbox
                      {...register("acceptTerms")}
                      onCheckedChange={(checked) => setValue("acceptTerms", checked as boolean)}
                    />
                    <div className="text-sm">
                      <p className="text-neutral-700">
                        I accept the{" "}
                        <a href="#" className="text-primary hover:underline">
                          Terms and Conditions
                        </a>{" "}
                        and{" "}
                        <a href="#" className="text-primary hover:underline">
                          Privacy Policy
                        </a>
                      </p>
                    </div>
                  </div>
                  {errors.acceptTerms && (
                    <p className="text-sm text-red-500 mb-4">{errors.acceptTerms.message}</p>
                  )}

                  <Button type="submit" className="w-full" size="lg">
                    Submit Exchange Request
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Summary Section */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-neutral-900">Exchange Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-neutral-500">From:</span>
                  <span className="font-medium">
                    {fromAmount || "0"} {fromCurrency || "Currency"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">To:</span>
                  <span className="font-medium">
                    {watch("toAmount") || "0"} {toCurrency || "Currency"}
                  </span>
                </div>
                {currentRate && (
                  <div className="flex justify-between text-sm">
                    <span className="text-neutral-500">Rate:</span>
                    <span>{currentRate.rate}</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-neutral-900">Why Choose Us?</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Shield className="h-5 w-5 text-green-500 mt-1" />
                  <div>
                    <h4 className="font-medium text-neutral-900">Secure & Safe</h4>
                    <p className="text-sm text-neutral-500">Your transactions are protected with bank-level security</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Layers className="h-5 w-5 text-blue-500 mt-1" />
                  <div>
                    <h4 className="font-medium text-neutral-900">Best Rates</h4>
                    <p className="text-sm text-neutral-500">Competitive exchange rates updated in real-time</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Confirmation Dialog */}
      <AlertDialog open={showConfirmation} onOpenChange={setShowConfirmation}>
        <AlertDialogContent className="max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Your Exchange</AlertDialogTitle>
            <AlertDialogDescription>
              Please review your exchange details before proceeding with payment.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-4 py-4">
            <div className="bg-neutral-50 p-4 rounded-lg">
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>From:</span>
                  <span className="font-medium">{watch("fromAmount")} {watch("fromCurrency")}</span>
                </div>
                <div className="flex justify-between">
                  <span>To:</span>
                  <span className="font-medium">{watch("toAmount")} {watch("toCurrency")}</span>
                </div>
                <div className="flex justify-between">
                  <span>Payment Method:</span>
                  <span className="font-medium">{watch("paymentMethod")}</span>
                </div>
              </div>
            </div>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmPayment} disabled={createOrderMutation.isPending}>
              {createOrderMutation.isPending ? "Creating Order..." : "Create Order"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Payment Confirmation Dialog */}
      <Dialog open={showSuccessDialog} onOpenChange={setShowSuccessDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Order Created Successfully!</DialogTitle>
          </DialogHeader>
          <div className="space-y-6 py-4">
            <div className="text-center">
              <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <p className="text-lg font-medium mb-2">Order #{orderNumber}</p>
              <p className="text-neutral-600">Your order has been created. Please choose your next step:</p>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-sm text-blue-800">
                <strong>Confirm Payment:</strong> Proceed with your payment to complete the exchange (up to 15 minutes for admin review)
              </p>
            </div>
            
            <div className="bg-yellow-50 p-4 rounded-lg">
              <p className="text-sm text-yellow-800">
                <strong>Cancel Order:</strong> Cancel this order if you've changed your mind
              </p>
            </div>
            
            <div className="grid grid-cols-1 gap-3">
              <Button 
                onClick={handleConfirmPaymentInDialog} 
                className="w-full h-12 text-base"
                disabled={confirmPaymentMutation.isPending}
              >
                {confirmPaymentMutation.isPending ? "Processing..." : "✓ Confirm Payment"}
              </Button>
              <Button 
                onClick={handleCancelOrder} 
                variant="outline" 
                className="w-full h-12 text-base"
                disabled={cancelOrderMutation.isPending}
              >
                {cancelOrderMutation.isPending ? "Canceling..." : "✗ Cancel Order"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}