import { Mail, Phone } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-white border-t border-neutral-200 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-neutral-900 mb-4">Doogle Online</h3>
            <p className="text-neutral-500 text-sm">
              Fast, secure, and reliable currency exchange service for all your financial needs.
            </p>
          </div>
          
          <div>
            <h4 className="text-sm font-semibold text-neutral-900 mb-3">Services</h4>
            <ul className="space-y-2 text-sm text-neutral-500">
              <li>
                <a href="#" className="hover:text-primary transition-colors">
                  Currency Exchange
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-primary transition-colors">
                  Rate Calculator
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-primary transition-colors">
                  Order Tracking
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-sm font-semibold text-neutral-900 mb-3">Support</h4>
            <ul className="space-y-2 text-sm text-neutral-500">
              <li>
                <a href="#" className="hover:text-primary transition-colors">
                  Contact Us
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-primary transition-colors">
                  Help Center
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-primary transition-colors">
                  Privacy Policy
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-sm font-semibold text-neutral-900 mb-3">Contact</h4>
            <div className="space-y-2 text-sm text-neutral-500">
              <p className="flex items-center">
                <Mail className="h-4 w-4 mr-2" />
                support@doogleonline.com
              </p>
              <p className="flex items-center">
                <Phone className="h-4 w-4 mr-2" />
                +252 61 234 5678
              </p>
            </div>
          </div>
        </div>
        
        <div className="border-t border-neutral-200 mt-8 pt-8 text-center text-sm text-neutral-500">
          <p>&copy; 2024 Doogle Online. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
