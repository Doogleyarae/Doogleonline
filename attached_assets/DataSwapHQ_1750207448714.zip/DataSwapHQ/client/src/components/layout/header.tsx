import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu } from "lucide-react";

const navigation = [
  { name: "Home", href: "/" },
  { name: "How it Works", href: "#how-it-works" },
  { name: "Exchange", href: "/" },
  { name: "Contact", href: "#contact" },
  { name: "About", href: "#about" },
];

export function Header() {
  const [location] = useLocation();

  return (
    <header className="bg-white shadow-sm border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link href="/" className="flex-shrink-0">
              <h1 className="text-2xl font-bold text-primary">Doogle Online</h1>
            </Link>
            <nav className="hidden md:ml-10 md:flex md:space-x-8">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className={`px-3 py-2 text-sm font-medium transition-colors ${
                    location === item.href || (item.name === "Exchange" && location === "/")
                      ? "text-primary border-b-2 border-primary"
                      : "text-neutral-500 hover:text-primary"
                  }`}
                >
                  {item.name}
                </Link>
              ))}
            </nav>
          </div>
          
          <div className="flex items-center space-x-4">
            <Link href="/auth">
              <Button variant="ghost" size="sm" className="text-neutral-500 hover:text-primary">
                Admin
              </Button>
            </Link>
            
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right">
                <nav className="flex flex-col space-y-4 mt-8">
                  {navigation.map((item) => (
                    <Link
                      key={item.name}
                      href={item.href}
                      className={`px-3 py-2 text-sm font-medium transition-colors ${
                        location === item.href || (item.name === "Exchange" && location === "/")
                          ? "text-primary"
                          : "text-neutral-500 hover:text-primary"
                      }`}
                    >
                      {item.name}
                    </Link>
                  ))}
                  <Link href="/auth">
                    <Button variant="outline" size="sm" className="mt-4">
                      Admin Access
                    </Button>
                  </Link>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
