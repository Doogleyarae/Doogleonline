# Currency Exchange Platform - Replit.md

## Overview

This is a full-stack currency exchange platform built with a modern tech stack. The application allows users to exchange currencies online with an admin dashboard for managing orders, exchange rates, and system settings. The platform supports email notifications, real-time order tracking, and multiple payment methods.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Styling**: Tailwind CSS with CSS variables for theming
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Passport.js with local strategy and session-based auth
- **Session Storage**: PostgreSQL-backed sessions using connect-pg-simple
- **Email Service**: Resend for transactional emails
- **Database Provider**: Neon Database (serverless PostgreSQL)

### Database Schema
- **users**: Admin authentication (username, password, role)
- **orders**: Customer exchange orders with status tracking
- **exchangeRates**: Dynamic currency exchange rates
- **currencyLimits**: Min/max limits per currency
- **systemMessages**: Customizable email templates

## Key Components

### Customer Flow
1. **Exchange Form**: Real-time rate calculation and order submission
2. **Order Status**: Public order tracking via order number
3. **Email Notifications**: Automated status updates

### Admin Dashboard
1. **Order Management**: View, accept, reject orders with search/filter
2. **Exchange Rate Management**: Update currency rates
3. **Currency Limits**: Configure min/max exchange amounts
4. **System Messages**: Customize email templates
5. **Authentication**: Secure admin login

### Authentication System
- Session-based authentication using Passport.js
- Password hashing with Node.js crypto (scrypt)
- Protected routes for admin functions
- Role-based access (admin-only system)

## Data Flow

1. **Customer Order**: Form submission → validation → order creation → email notification
2. **Admin Processing**: Order review → status update → customer notification
3. **Rate Updates**: Admin updates rates → immediate availability for new orders
4. **Email Flow**: Order events trigger customizable email templates

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL driver
- **drizzle-orm**: Type-safe database ORM
- **passport**: Authentication middleware
- **resend**: Email service provider
- **@tanstack/react-query**: Data fetching and caching
- **@radix-ui**: Headless UI components
- **tailwindcss**: Utility-first CSS framework

### Development Tools
- **vite**: Build tool and development server
- **typescript**: Type checking
- **drizzle-kit**: Database migrations
- **esbuild**: Production bundling

## Deployment Strategy

### Replit Configuration
- **Modules**: nodejs-20, web, postgresql-16
- **Development**: `npm run dev` (port 5000)
- **Production**: `npm run build && npm run start`
- **Database**: Automatic PostgreSQL provisioning

### Build Process
1. Frontend: Vite builds React app to `dist/public`
2. Backend: esbuild bundles server to `dist/index.js`
3. Database: Drizzle migrations ensure schema consistency

### Environment Variables
- `DATABASE_URL`: PostgreSQL connection string
- `SESSION_SECRET`: Session encryption key
- `RESEND_API_KEY`: Email service authentication

## Changelog
- June 17, 2025: Initial setup and complete platform deployment
- June 17, 2025: Successfully deployed full-featured currency exchange platform with:
  - Working exchange form with real-time currency conversion
  - Email notification system with Resend integration
  - Admin dashboard for order management and rate updates
  - Order status tracking with progress indicators
  - Database integration with PostgreSQL
  - Authentication system for admin access
  - Complete order workflow from submission to completion
- June 18, 2025: Updated currency options to include mobile money and crypto:
  - Removed all traditional currencies (USD, EUR, GBP, SOS)
  - Added mobile money: Zaad, Sahal, EVC Plus, eDahab, Premier Bank, MoneyGo
  - Added cryptocurrency: TRX, TRC20, PEB20
  - Simplified form by removing payment method selection
  - Platform now specializes in mobile money and crypto exchanges
- June 18, 2025: Enhanced admin dashboard with comprehensive management features:
  - Added exchange rate management with inline editing functionality
  - Implemented balance management dashboard with real-time balances
  - Created contacts management system for customer information
  - Added wallet management with copy-to-clipboard functionality
  - Integrated copy functionality for wallet addresses, balances, and rates
  - Streamlined admin interface to 5 focused management tabs (removed currency limits)
  - Enhanced user experience with visual feedback and notifications
  - Added MoneyGo currency support across all platform features

## Deployment Status
- ✓ Platform is live and processing real orders
- ✓ Email notifications working (confirmed with test order EX-2025-270266)
- ✓ Real-time currency conversion functional
- ✓ Admin dashboard accessible at /auth
- ✓ Order status tracking working at /order-status/{orderNumber}

## User Preferences

Preferred communication style: Simple, everyday language.